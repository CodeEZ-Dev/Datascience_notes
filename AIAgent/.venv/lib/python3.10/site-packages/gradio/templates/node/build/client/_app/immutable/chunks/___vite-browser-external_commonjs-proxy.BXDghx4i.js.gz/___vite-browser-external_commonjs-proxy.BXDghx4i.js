import { _ as __viteBrowserExternal } from "./__vite-browser-external.CURh0WXD.js";
import { e as getAugmentedNamespace } from "./2.DGiuLZW-.js";
const require$$0 = /* @__PURE__ */ getAugmentedNamespace(__viteBrowserExternal);
export {
  require$$0 as r
};
