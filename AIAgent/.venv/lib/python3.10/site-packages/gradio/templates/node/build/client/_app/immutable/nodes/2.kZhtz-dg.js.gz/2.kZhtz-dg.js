import { z, _ } from "../chunks/2.DGiuLZW-.js";
export {
  z as component,
  _ as universal
};
